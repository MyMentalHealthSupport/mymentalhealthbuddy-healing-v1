# MyMentalHealthBuddy Healing V1

This is a simple Express + TypeScript starter server configured to auto-run in Replit.

## Quick Start

1. Install dependencies:
   ```
   npm install
   ```

2. Run in development mode:
   ```
   npm run dev
   ```